"use strict";
$(document).ready(function (){
    $("#btnAccedi").on("click",getModal);
    $("#pError").hide();
});

function getModal(){
    if($("#btnAccedi").html()=="Accedi") {
        $("#btnLogin").on("click",login);
        $("#modalLogin").modal();
    }
}

function login(){
    let par={user:$("#txtUser").val(), pwd:$("#txtPwd").val()};
    send_request("php/login.php","POST",par,ctrlLogin);
}

function ctrlLogin(responseText){
    alert(responseText);
    if(responseText!="Login errato"){
        $("#btnAccedi").html("Logout");
        $("#modalLogin").modal("hide");
        let datiUtente=JSON.parse(responseText);
        $("#spanProfile").html(datiUtente["cog"] + " " + datiUtente["nom"]);
    }
    else{
        $("#pError").show();
        $("#btnAccedi").html("Accedi");
    }
}