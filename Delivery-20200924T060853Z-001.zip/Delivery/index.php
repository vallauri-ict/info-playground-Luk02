<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>DamoDelivery</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/landing-page.css" rel="stylesheet">
  <link href="css/index.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-light bg-light static-top">
    <div class="container">
      <a class="navbar-brand" href="#">Damo Delivery</a>
        <div id="myProfile"><i class='fas fa-user-alt' style='font-size:16px;padding-right: 5px'></i> <span id="spanProfile">il mio profilo</span> <i class="fas fa-shopping-cart"></i></div>
      <button type="button" class="btn btn-primary"  id="btnAccedi">Accedi</button>
    </div>
  </nav>

  <!-- Login -->
  <div class="modal fade" id="modalLogin">
      <div class="modal-dialog">
          <div class="modal-content">

              <!-- Modal Header -->
              <div class="modal-header">
                  <h4 class="modal-title">Accedi alla tua area personale</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>

              <!-- Modal body -->
              <div class="modal-body">
                  <div class="row">
                      <div class="col-sm-2 align-content-center"><label for="txtUser" class="mx-auto">Username</label></div>
                      <div class="col-sm-10 align-content-center"><input type="text" id="txtUser" style="width: 100%" value="3"/></div>
                  </div>
                  <div class="row">
                      <div class="col-sm-2 align-content-center"><label for="txtPwd">Password</label></div>
                      <div class="col-sm-10 align-content-center"><input type="password" id="txtPwd" style="width: 100%" value="3"/></div>
                  </div>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                  <div class="row">
                      <div class="col-sm-8"><p id="pError" style="float:left;display:inline">Username e/o password errati</p></div>
                      <div class="col-sm-2"><button type="button" class="btn btn-primary" id="btnLogin">Login</button></div>
                      <div class="col-sm-2"><button type="button" class="btn btn-danger" data-dismiss="modal">Close</button></div>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-12 mx-auto">
          <h1 class="mb-5">Delivery</h1>
        </div>
          <div class="col-xl-12 mx-auto">
              <h2 class="mb-5">Sfoglia il menù e prenota il tuo pranzo</h2>
              <h3 class="mb-5" id="datiUtente">Esegui il login per prenotare</h3>
          </div>
      </div>
    </div>
  </header>

  <!-- Icons Grid -->
  <div class="bg-light text-left" id="secMenu">

  </div>









  <!-- Footer -->
  <footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
          <ul class="list-inline mb-2">
            <li class="list-inline-item">
              <a href="#">About</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">Contact</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">Terms of Use</a>
            </li>
            <li class="list-inline-item">&sdot;</li>
            <li class="list-inline-item">
              <a href="#">Privacy Policy</a>
            </li>
          </ul>
          <p class="text-muted small mb-4 mb-lg-0">&copy; Your Website 2019. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
          <ul class="list-inline mb-0">
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-facebook fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item mr-3">
              <a href="#">
                <i class="fab fa-twitter-square fa-2x fa-fw"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fab fa-instagram fa-2x fa-fw"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="js/index.js"></script>
  <script src="js/libreria.js"></script>
</body>

</html>
