<?php
    $con=new mysqli("localhost","root","","delivery");
    if($con->connect_errno)
        die("Errore connessione db. " . $con->connect_errno . " - " . $con->connect_error);
    $sql="select * from utenti where codUtente = '" . $_POST['user'] . "'";
    $rs=$con->query($sql);
    if(!$rs)
        die("Errore nella query. " . $con->errno . " - " . $con->error);
    if($rs->num_rows==0)
         echo("Login errato");
    else{
        $pwd=$_POST["pwd"];
        $record=$rs->fetch_assoc();
        if($pwd==$record["pass"]){
            session_start();
            $_SESSION["user"]=$record["cognome"] . " " . $record["nome"];
            $jsonObj=(object)[
                "cog" => $record["cognome"],
                "nom" => $record["nome"],
                "id" => $record["codUtente"]
            ];
            echo json_encode($jsonObj);
        }
        else
            echo("Login errato");
    }
    $con->close();
?>
